def transfer_to_agent(agent_name: str) -> Any:
  """Transfer the user to the specified agent."""
  return LlmResponse(
    content=Content(
      parts=[Part(
        function_call=FunctionCall(
          name="transfer_to_agent",
          args={"agent_name": agent_name}
          ))],
      role="model"))


def before_model_callback(callback_context: CallbackContext, llm_request: LlmRequest) -> Optional[LlmResponse]:
  customer_name = callback_context.variables["customer_name"]
  tool_context.state['transfer_customer_id'] = customer_id
  if customer_name == "Fede":
    return transfer_to_agent("DFCX")

