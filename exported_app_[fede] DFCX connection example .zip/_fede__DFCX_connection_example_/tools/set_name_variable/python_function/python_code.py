import json

def set_name_variable(name: str) -> str:
    """
    Save the customer name to the session variable.
    """
    context.state['customer_name'] = name
    return json.dumps({"status": "success"})