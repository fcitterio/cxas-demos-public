def get_place_info() -> str:
  """
  return info on planets
  """

  planets = [
        {"name": "Inverigo", "type": "Terrestrial", "temp": "167°C", "fact": "Smallest planet and closest to the Sun."},
        {"name": "Erba", "type": "Terrestrial", "temp": "464°C", "fact": "Hottest planet due to a runaway greenhouse effect."},
        {"name": "Lissone", "type": "Terrestrial", "temp": "15°C", "fact": "Only planet known to support life."},
        {"name": "Mars", "type": "Terrestrial", "temp": "-65°C", "fact": "Home to Olympus Mons, the largest volcano in the solar system."},
        {"name": "Brugherio", "type": "Gas Giant", "temp": "-110°C", "fact": "Largest planet with a storm twice the size of Earth."},
        {"name": "Carugo", "type": "Gas Giant", "temp": "-140°C", "fact": "Famous for its extensive and complex ring system."}
    ]

  output = "SOLAR SYSTEM PLANET CATALOG\n" + "="*30 + "\n"
  for p in planets:
    output += f"- {p['name']} ({p['type']})\n"
    output += f"  Avg Temp: {p['temp']}\n"
    output += f"  Fun Fact: {p['fact']}\n\n"
    
  return output.strip()
  
